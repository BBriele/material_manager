const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const moment = require('moment');


const apiMovimentiRoutes = require('./api/movimentiApi.js');
const apiMaterialiRoutes = require('./api/materialiApi');
const apiOrdiniRoutes = require('./api/ordiniApi');
const routes = require('./routes/routes');
const web_script = require('./public/web_script.js');
const db = require('./db');
const path = require('path');
const { appendFile } = require('fs/promises');



mongoose.connect('mongodb://127.0.0.1:27017/movimenti', { useNewUrlParser: true });

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


// View engine setup
app.set('view engine', 'ejs');

//app.set('/apiMovimenti', apiMovimentiRoutes);

app.use('/apiMovimenti', apiMovimentiRoutes);
app.use('/apiMateriali', apiMaterialiRoutes);
app.use('/apiOrdini', apiOrdiniRoutes);
app.use('/', routes);


//---------------------------------------------------------------
//  PER ACCEDERE A GLI SCRIPT E CSS
app.use(express.static('public'));
app.use(express.static('views'));
//app.use(express.static('js'));
//---------------------------------------------------------------

console.log(__dirname);



/*app.get(['/home'], (req, res) => {
  res.render(path.join(__dirname, 'views', 'index.ejs'));
});*/

app.get(['/visualizza_storico', '/visualizza_storico/:id'], (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'pg_visual_storico.html'));
});

app.get('/visualizza_materiale', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'pg_visual_materiale.html'));
});

app.get(['/visualizza_riepilogo', '/visualizza_riepilogo/:id'], (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'pg_visual_riepilogo.html'));
});

app.get(['/visualizza_necessario'], (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'pg_visual_necessario.html'));
});

app.listen(3001, () => {
  console.log('Server started on port 3001');
});
