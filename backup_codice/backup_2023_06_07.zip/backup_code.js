const JSZip = require('jszip');
const fs = require('fs');
const path = require('path');
const moment = require('moment');

// Lista dei file e delle cartelle da includere nel backup
const filesAndFolders = [
  './api',
  './backupDB',
  './models',
  './public',
  './routes',
  './views',
  './backup_code.js',
  './backup.js',
  './config_file_backup.yaml',
  './config_file.yaml',
  './db.js',
  './package-lock.json',
  './package.json',
  './server.js'
];
// Percorso di destinazione per l'archivio di backup
const destinationPath = './backup_codice/';

// Genera il nome dell'archivio di backup con la data di esecuzione
const currentDate = moment().format('YYYY_MM_DD');
const backupName = `backup_${currentDate}.zip`;

// Crea un nuovo oggetto JSZip
const zip = new JSZip();

// Aggiunge i file e le cartelle all'archivio ZIP
for (const fileOrFolder of filesAndFolders) {
  const stats = fs.statSync(fileOrFolder);

  if (stats.isFile()) {
    const fileData = fs.readFileSync(fileOrFolder);
    const relativePath = path.relative('.', fileOrFolder);
    zip.file(relativePath, fileData);
  } else if (stats.isDirectory()) {
    const folderName = path.basename(fileOrFolder);
    const relativePath = path.relative('.', fileOrFolder);
    zip.folder(relativePath);
  }
}

// Crea l'archivio ZIP
zip.generateAsync({ type: 'nodebuffer' })
  .then((content) => {
    const backupPath = path.join(destinationPath, backupName);

    // Salva l'archivio ZIP sul disco
    fs.writeFileSync(backupPath, content);

    console.log(`Backup creato: ${backupPath}`);
  })
  .catch((error) => {
    console.error('Si è verificato un errore durante la creazione del backup:', error);
  });
